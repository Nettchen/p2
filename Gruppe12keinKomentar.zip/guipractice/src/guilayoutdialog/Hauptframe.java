package guilayoutdialog;

import java.awt.BorderLayout;       

import java.awt.GridLayout;
//import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.awt.event.MouseAdapter;
//import java.awt.event.MouseEvent;
//import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
//import java.io.File;
//import java.io.FileWriter;
import java.io.IOException;

import javax.swing.*;
 


/**
 * Hauptfenster und einige Button.
 *Klicken auf Datei-Menu, gibt es vier MenuItem, ��oeffnen�� , ��neu�� , ��Speichern unter�� und ��Beenden��.
 *
 *Klicken auf ��oeffnen��, kann man Datei lesen.
 *Klicken auf ��neu��, kann man ein neu Datei mit keine Waren bekommen.
 *Klicken auf ��speichern unter��, kann man die Datei unter beliebigen Folder mit beliebigen Namen speichern.
 *Klicken auf ��beenden��, schliesst der Fenster.
 *
 *Klicken auf ��add��, kann man eines neuen Objekts hinzufuegen.
 *Selektieren eine Ware und klicken auf ��delet��, wird selektierte Ware geloescht.
 *Selektieren eine Ware und klicken auf ��aendern��, kann man der Attribute einer Ware aendern.
 *Klicken auf ��Speichern��, kann man die Aktuelle Daten in einer temporaeren Datei speichern.

 * 
 */


public class Hauptframe extends JFrame implements ActionListener {
	
	
	
	private JMenuBar mb = new JMenuBar () ; 
	
    private JMenu dateiMenu = new JMenu("Datei");
	
	private JMenuItem dateoeffnen = new JMenuItem ("Oeffnen"); 
	private JMenuItem datenew = new JMenuItem ("Neu");         
	private JMenuItem speichernunter = new JMenuItem ("Speichern unter");  
	private JMenuItem datebeenden = new JMenuItem ("Beenden");  
	

	private JButton add = new JButton ("add");
	private JButton delet = new JButton ("delet");
	private JButton aendern  = new JButton ("aendern");
	private JButton speichern = new JButton ("speichern") ; 
	
	private GUIWarenlist guilist = new GUIWarenlist( this );      
	
	
	private JPanel westpanel = new JPanel();    
	private JPanel eastpanel = new JPanel ();   
	
    Warenforlist warenforlist = new Warenforlist(); 
	                                                
	 
	
	
	class MeinWListener extends WindowAdapter { 
		
		void Windowclosing () {
		System.out.println("exit");
		System.exit(0);
		}
		
			
	}
	
    public Hauptframe (String a ){
	   super( a );
	   
	   this.addWindowListener(new MeinWListener());
	   this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	   
	   this.setJMenuBar(mb); 
	   
	   mb.add(dateiMenu);
	  
	   dateoeffnen.addActionListener(this); 
	   datenew.addActionListener(this);
	   speichernunter.addActionListener(this);
	   datebeenden.addActionListener(this);
	   
	   dateiMenu.add(dateoeffnen); 
	   dateiMenu.add(datenew);    
	   dateiMenu.add(speichernunter);
	   dateiMenu.addSeparator();   
	   dateiMenu.add(datebeenden);
	   
	  
	   
	   
	   add.addActionListener(this);          
	   delet.addActionListener(this);
	   aendern.addActionListener(this);
	   speichern.addActionListener(this);
	   
	   westpanel.setLayout(new GridLayout(4,1));  
	   westpanel.add(add);                        
	   westpanel.add(delet);
	   westpanel.add(aendern );
	   westpanel.add(speichern);
	 
	   guilist.setWaren(warenforlist);            
	   eastpanel.add(guilist);                    
		

	   this.setSize(900, 800);                    
	   this.setVisible(true);                     
	   
	  
	   this.add(westpanel,BorderLayout.WEST);     
	   this.add(guilist,BorderLayout.CENTER);     
		
		   
	   
   }
	
   public static void main(String[] args) { 
		// TODO Auto-generated method stub
	   Hauptframe hauptframe = new Hauptframe("Laden");
	}
	
	
	
	
	
	
	
	public GUIWarenlist getGuilist() {  
		
	return guilist;
	
}

	@Override   
	public void actionPerformed(ActionEvent arg0) {
		
		
		if(arg0.getSource().equals(add)) { 
			Dialogadd add = new Dialogadd (this,"Add",this) ;
		}
		
    
		if(arg0.getSource().equals(delet)) {   
			int index = guilist.getSelectedIndex();   
			if(index >= 0 ) {
				guilist.getMyListModel().removeElementAt(index); 
		        warenforlist.remove(index); 
			}
		}
		
		if(arg0.getSource().equals(aendern)) { 
			int index = guilist.getSelectedIndex();
			if(index >= 0 ) {
				DialogshowData show = new DialogshowData (this,"aendern" , this) ;
			}
        }


		if(arg0.getSource().equals(speichern)) { 
			
			String dateiName = "Data/voruebergehend.dat";    
			
			WarenDAO dao = new WarenDAO (dateiName, true); 
			try {
				dao.write(warenforlist);
			}
			catch (IOException e) {
				System.out.println (e.getMessage());	  
			}
			dao.close();                                 
			
			guilist.setWaren(warenforlist);              
	         
		}
		
		
		
		if(arg0.getSource().equals(dateoeffnen)) { 
			dateiOeffnen() ;
		}
		
		if( arg0.getSource().equals(datenew)) { 
			dateineu();	
			
		}
		
	
		if(arg0.getSource().equals( speichernunter )) {  
			JFileChooser chooser = new JFileChooser();

		    int returnVal = chooser.showSaveDialog(null);

		    if(returnVal == JFileChooser.APPROVE_OPTION) {
		       String dateiName = chooser.getSelectedFile().getAbsolutePath() ;
		    
			
					WarenDAO dao = new WarenDAO (dateiName, true); 
			try {
				dao.write(warenforlist);
			}
			catch (IOException e) {
				System.out.println (e.getMessage());	
			}
			dao.close();
			
			guilist.setWaren(warenforlist);
		    } 
		}
		
		
		if( arg0.getSource().equals(datebeenden)) { 
			System.out.println("exit");
			System.exit(0);
		}
		

	}
	
      public void dateineu () {
	
	
	    warenforlist.removeAll(warenforlist) ; 
	    guilist.setWaren(warenforlist);        
	
     }
	

	
      public void dateiOeffnen(){
	    JFileChooser chooser = new JFileChooser();

	    int returnVal = chooser.showOpenDialog(null);

	    if(returnVal == JFileChooser.APPROVE_OPTION) { 
	       String dateiName = chooser.getSelectedFile().getAbsolutePath() ;
	    
	  
		WarenDAO dao2 = new WarenDAO (dateiName, false); 
		try {
			dao2.read(warenforlist);
		}
		catch (IOException e) {
			System.out.println (e.getMessage());			
		}
		dao2.close();
		
		guilist.setWaren(warenforlist);
		
	
	  }
	 
}
 
}