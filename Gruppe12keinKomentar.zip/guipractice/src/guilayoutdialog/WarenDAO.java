package guilayoutdialog;

import java.io.IOException;




public class WarenDAO  extends DAO {
	
	
	
	public WarenDAO (String dateiName, boolean openForWrite) {

		super (dateiName, openForWrite);
	}
	
	
	public void write (Object obj) throws IOException {
		
		if (out != null) {
			
			Warenforlist waren = (Warenforlist)obj; 
			
			out.writeInt(waren.size());     
			
			WareDAO wDAO = new WareDAO (null, out);  
			
			for (Ware w: waren) {     
				
				wDAO.write(w);
			}
		}
	}
	
	
	public void read (Object obj) throws IOException {
		
		if (in != null) {
			
			Warenforlist waren = (Warenforlist)obj;
			
			
			int nWare = in.readInt();               
			
			
			WareDAO wDAO = new WareDAO (in, null);  
			for (int i=0; i<nWare; ++i) {           
				Ware w = new Ware();                
				wDAO.read(w);                       
				waren.add(w);                       
			}
		}
	}
	
}
