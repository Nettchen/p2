package guilayoutdialog;

import java.util.ArrayList;


public class Warenforlist extends ArrayList<Ware> { 
	
	
	public void addWare ( Ware w ) { 
		
		super.add(w) ;
	}

}
