package guilayoutdialog;

import java.awt.Window;
import java.awt.event.MouseAdapter;  
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;




public class GUIWarenlist extends JList<String> {


	private DefaultListModel<String> myListModel = new DefaultListModel<String> ();  
	
	private Hauptframe mainframe ;
	
	
	private class ListClickHandler extends MouseAdapter {
		
		public void mouseClicked(MouseEvent e) {
			
			
			if (e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) { 
				
				int index = getSelectedIndex();
				if (index >= 0)	{
					
					DialogshowData diashow = new DialogshowData(mainframe, "show" , mainframe );
				
					
					
				}
			}
					
		}
		
	}


	public GUIWarenlist (Hauptframe a ) { 
		
		this.mainframe = a ;
		
		setModel (myListModel);
		
		addMouseListener (new ListClickHandler()); 
	}
	
	public DefaultListModel<String> getMyListModel() {
		
		return myListModel;
		
	}

	public void setWaren (ArrayList<Ware> warenlist) { 
		
		
		myListModel.removeAllElements();               
		int nWare = warenlist.size() ;                 
		for (int i = 0 ; i < nWare ; ++i) {  
			
			myListModel.addElement(warenlist.get(i).getName());   
		}
		
	}
}
