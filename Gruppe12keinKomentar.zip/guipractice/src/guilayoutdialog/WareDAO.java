package guilayoutdialog;

import java.io.DataInputStream; 
import java.io.DataOutputStream;
import java.io.IOException;



public class WareDAO extends DAO {

	
	
	public WareDAO (String dateiName, boolean openForWrite) {
		
		super (dateiName, openForWrite);
	}
	
	
	
	public WareDAO (DataInputStream in, DataOutputStream out) {
		
		super (in, out);
	}
	
	
	
	public void write (Object obj) throws IOException { 
		
		if (out != null) {             
			
			Ware w = (Ware)obj;
			
			out.writeUTF	(w.getName()); 
			out.writeInt	(w.getNummer());
			out.writeBoolean(w.isLage());
			out.writeDouble	(w.getPreis());
		}
	}
	
	
	
	public void read (Object obj) throws IOException {
		
		if (in != null) {      
			
			Ware w  = (Ware)obj;
			
			w.setName		(in.readUTF());  
			w.setNummer		(in.readInt());
			w.setLage	(in.readBoolean());
			w.setPreis		(in.readDouble());
		}
	}
}
