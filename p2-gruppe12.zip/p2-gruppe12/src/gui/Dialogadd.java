package gui;


import java.awt.BorderLayout;    

import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Ware;




public class Dialogadd extends JDialog implements ActionListener {
	

	
	private Hauptframe mainframe ; 

	
    private String[] texte = { "true", "false" }; 
	
	
	private JLabel Num = new JLabel ("Nummer"); 
	private JLabel Name = new JLabel ("Name");
	private JLabel Preis = new JLabel ("Preis");
	private JLabel Lage = new JLabel ("Lager");
	
	private JTextField tfnum = new JTextField ("Max 9 Stelle",10);  
	private JTextField tfnam = new JTextField (10);
	private JTextField tfpre = new JTextField ( "Ein double ",10);
	
	private JComboBox<String> cbox	= new JComboBox<String> (texte);
	
	private JButton neubt1 = new JButton ("Add");      
	private JButton neubt2 = new JButton ("Abbrechen");
	
	public Dialogadd(Window parent, String title , Hauptframe a ) { 
		
		
		
		this.mainframe = a ;
		
		tfnum.addActionListener(this); 
		tfnam.addActionListener(this);
		tfpre.addActionListener(this);
		cbox.addActionListener(this); 
		
		neubt1.addActionListener(this); 
		neubt2.addActionListener(this);
		
		cbox.setSelectedIndex(0); 
	
		JPanel panel1 = new JPanel (new GridLayout(2,4,3,3)); 
		JPanel panel2 = new JPanel (new GridLayout(1,2,3,3)); 
		
		panel1.add(Num);
		panel1.add(Name);
		panel1.add(Preis);
		panel1.add(Lage);
		panel1.add(tfnum);
		panel1.add(tfnam);
		panel1.add(tfpre);
		panel1.add(cbox);
		
		
		panel2.add(neubt1);
		panel2.add(neubt2);
	
		setLayout (new BorderLayout ()); 
		
		
		this.getContentPane().add(panel2,BorderLayout.SOUTH); 
		this.getContentPane().add(panel1,BorderLayout.CENTER);
		
		this.setTitle(title);
		
		
		
		Point ownerPosition = parent.getLocation();    
		setLocation (ownerPosition.x+200, ownerPosition.y+300);
		
		pack();  
		
		setVisible (true); 
		
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource().equals(neubt1)) {  
			addneu () ;
        }
		if(arg0.getSource().equals(neubt2)) { 
			System.out.println("exit");
			setVisible (false);
        }
		
	}
	
     private boolean inputOKnum (String text) {
    	  	 
    	 if( text.equals("")) {
    		 return true ;
    	 }
    	else{  
    		for (int i = text.length(); --i>=0;) {
    		    int chr = text.charAt(i);
    		    if(chr < 48 || chr > 57)
    		    return true;
    		  }  		  
    		 
		    int zahl = Integer.parseInt (text);
		    return zahl > 1000000000;		
    	 }
    }  
     
    private boolean inputOKpre (String text) {
     	 
    	if( text.equals("")) {
   		 return true ;
   	    }
   	  else{  
   		  for (int i = text.length(); --i>=0;) {
   		    int chr = text.charAt(i);
   		    if(chr < 48 || chr > 57)
   		    	if( chr != 44 && chr != 46)
   		    	  return true;		    
   		        }  		  
		  return false ;  	
   	    }
   	     
    }
    
       	
	public void addneu () {
	
		// Mit equals kann man zwei Zeichenketten auf inhaltliche Gleichheit ��berpr��fen .
			if(inputOKnum(tfnum.getText()) || tfnam.getText().equals("") || 
					inputOKpre(tfpre.getText()) ) {
				
				String show = "";
				
			   if(inputOKnum(tfnum.getText()))	
				   show =  show + "Bitte geben Sie ein Nummer, Max 9 Stelle " + "\n" ;
			   
			   if(tfnam.getText().equals(""))
				   show = show + "Bitte geben Sie den Name der Ware" + "\n" ;
				   	   
			   if(inputOKpre(tfpre.getText()))
				   show =  show  + "Bitte geben Sie den Preis der Ware" + "\n" ;	
			   
			    JOptionPane.showMessageDialog(this, show, "Fehler", JOptionPane.ERROR_MESSAGE);
			   
	
			} 
		    else {
		 	
            int  num = Integer.parseInt(tfnum.getText());      
			String name = tfnam.getText() ;
			String spreis = tfpre.getText() ;
			double preis = Double.parseDouble(spreis.replace(",", "."));
			boolean lage ;
			int index = cbox.getSelectedIndex();               
			   if(index == 0)
				   lage = true ;
			   else
				   lage = false ;
			   
		    Ware zwischenwert = new Ware (name,num,lage,preis) ;   
		    
		    mainframe.waren.add(zwischenwert);             
		    
		    mainframe.getGuilist().setWaren(mainframe.waren); 
		 	    
			setVisible (false);                                      
		}
	
	
	}	
	
	

}
