package gui;

import java.awt.BorderLayout;   
      

import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.WindowAdapter;

import java.io.IOException;

import javax.swing.*;

import model.WarenDAO;
import model.Waren;
 


/**
 * Hauptfenster und einige Button.
 *Klicken auf Datei-Menu, gibt es vier MenuItem, ��oeffnen�� , ��neu�� , ��Speichern unter�� und ��Beenden��.
 *
 *Klicken auf ��oeffnen��, kann man Datei lesen.
 *Klicken auf ��neu��, kann man ein neu Datei mit keine Waren bekommen.
 *Klicken auf ��speichern unter��, kann man die Datei unter beliebigen Folder mit beliebigen Namen speichern.
 *Klicken auf ��beenden��, schliesst der Fenster.
 *
 *Klicken auf ��add��, kann man eines neuen Objekts hinzufuegen.
 *Selektieren eine Ware und klicken auf ��delet��, wird selektierte Ware geloescht.
 *Selektieren eine Ware und klicken auf ��aendern��, kann man der Attribute einer Ware aendern.
 *Klicken auf ��Speichern��, kann man die Daten in der Datei speichern.

 * 
 */


public class Hauptframe extends JFrame implements ActionListener {
	
	
	//wichtige Komponenten der Hauptfenster als Eigenschaften/Attribute
	private JMenuBar mb = new JMenuBar () ;   
	
    private JMenu dateiMenu = new JMenu("Datei");
	
	private JMenuItem dateoeffnen = new JMenuItem ("Oeffnen"); 
	private JMenuItem datenew = new JMenuItem ("Neu");         
	private JMenuItem speichernunter = new JMenuItem ("Speichern unter");  
	private JMenuItem datebeenden = new JMenuItem ("Beenden");  
	

	private JButton add = new JButton ("add");
	private JButton delet = new JButton ("delet");
	private JButton aendern  = new JButton ("aendern");
	private JButton speichern = new JButton ("speichern") ; 
	
	private GUIWarenlist guilist = new GUIWarenlist( this );      
	
	private JPanel westpanel = new JPanel();    
	private JPanel eastpanel = new JPanel ();   
	
	private String dateiName = "" ; 
	
    Waren waren = new Waren(); 
	                                                
	 
	
	
	class MeinWListener extends WindowAdapter { 
		
		void Windowclosing () {
		System.out.println("exit");
		System.exit(0);
		}
		
			
	}
	
	
	//Konstruktor des Hauptfensters
    public Hauptframe (String a ){
	   super( a );
	   
	   this.addWindowListener(new MeinWListener());
	   this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	   
	   this.setJMenuBar(mb); 
	   
	   mb.add(dateiMenu);
	  
	   dateoeffnen.addActionListener(this); 
	   datenew.addActionListener(this);
	   speichernunter.addActionListener(this);
	   datebeenden.addActionListener(this);
	   
	   dateiMenu.add(dateoeffnen); 
	   dateiMenu.add(datenew);    
	   dateiMenu.add(speichernunter);
	   dateiMenu.addSeparator();   
	   dateiMenu.add(datebeenden);
	   
	  
	   
	   
	   add.addActionListener(this);          
	   delet.addActionListener(this);
	   aendern.addActionListener(this);
	   speichern.addActionListener(this);
	   
	   westpanel.setLayout(new GridLayout(4,1));  
	   westpanel.add(add);                        
	   westpanel.add(delet);
	   westpanel.add(aendern );
	   westpanel.add(speichern);
	 
	   guilist.setWaren(waren);            
	   eastpanel.add(guilist);                    
		

	   this.setSize(900, 800);                 
	   this.setVisible(true);                      
	   
	
	   this.add(westpanel,BorderLayout.WEST);     
	   this.add(guilist,BorderLayout.CENTER);     
		
		   
	   
   }
	
    //Hauptmethode
   public static void main(String[] args) { 
		// TODO Auto-generated method stub
	   Hauptframe hauptframe = new Hauptframe("Happy Supermarkt"); 
	   
   }
		
	
   
	public GUIWarenlist getGuilist() {  
		
	  return guilist;
	
   }

	//reagieren auf klick der Buttons
	@Override   
	public void actionPerformed(ActionEvent arg0) {
		
		//Reagieren  auf klick des Buttons "add".
		if(arg0.getSource().equals(add)) { 
			Dialogadd add = new Dialogadd (this,"Add",this) ;
		}
		
		//Reagieren  auf klick des Buttons "delet".
		if(arg0.getSource().equals(delet)) {   
			int index = guilist.getSelectedIndex();   
			if(index >= 0 ) {
				guilist.getMyListModel().removeElementAt(index); 
		        waren.remove(index); 
			}
		}
		
		//Reagieren  auf klick des Buttons "aendern".
		if(arg0.getSource().equals(aendern)) { 
			int index = guilist.getSelectedIndex();
			if(index >= 0 ) {
				DialogshowData show = new DialogshowData (this,"aendern" , this) ;
			}
        }

		//Reagieren  auf klick des Buttons "speichern".
		if(arg0.getSource().equals(speichern)) { 
			
			if(this. dateiName == "") {	
				
				dateispeichern () ;
				
			}else {
				
			WarenDAO dao = new WarenDAO (this.dateiName, true); 
			
			try {
				dao.write(waren);	
			}
			catch (IOException e) {
				System.out.println (e.getMessage());
			}
			
			dao.close();                                 
			
			guilist.setWaren(waren);
			
			} 
		}
		
		
		//Reagieren  auf klick des Buttons "oeffnen".
		if(arg0.getSource().equals(dateoeffnen)) { 
			  
		    JFileChooser chooser = new JFileChooser();

		    int returnVal = chooser.showOpenDialog(null);

		    if(returnVal == JFileChooser.APPROVE_OPTION) { 
		       this.dateiName = chooser.getSelectedFile().getAbsolutePath() ;
		    
			WarenDAO dao = new WarenDAO (this.dateiName, false); 
			
			try {
				dao.read(waren);
			}
			catch (IOException e) {
				System.out.println (e.getMessage());			
			}
			dao.close();
			
			guilist.setWaren(waren);
				
		  }
		    
		}
		
		//Reagieren  auf klick des Buttons "neu".
		if( arg0.getSource().equals(datenew)) { 
			 waren.removeAll(waren) ; 
			 guilist.setWaren(waren);        
			 this.dateiName = "" ;	
			
		}
		
		//Reagieren  auf klick des Buttons "speichern unter ".
		if(arg0.getSource().equals( speichernunter )) {  
			dateispeichern () ;
		}
		
		//Reagieren  auf klick des Buttons "beenden".
		if( arg0.getSource().equals(datebeenden)) { 
			System.out.println("exit");
			System.exit(0);
		}
		

	}
	
     
	
    
      
    public void dateispeichern () {
    	JFileChooser chooser = new JFileChooser();

	    int returnVal = chooser.showSaveDialog(null);

	    if(returnVal == JFileChooser.APPROVE_OPTION) {
	       this.dateiName = chooser.getSelectedFile().getAbsolutePath() ;
	    	
		WarenDAO dao = new WarenDAO (this.dateiName, true); 
		
		try {
			dao.write(waren);
		}
		catch (IOException e) {
			System.out.println (e.getMessage());	
		}
		dao.close();
		
		guilist.setWaren(waren);
		
	    } 
    }
 
}