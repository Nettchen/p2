package gui;


import java.awt.event.MouseAdapter;  
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JList;


import model.Ware;



//GUIWarenliste erben von JList
public class GUIWarenlist extends JList<String> {


	private DefaultListModel<String> myListModel = new DefaultListModel<String> ();  ///DefaultListModell wird erzeugt
	
	private Hauptframe mainframe ;
	
	/** Hier definieren wir einen Eventhandler, um auf Mausereignisse zu reagieren.
	 * Funktion: "aederung" wird hier implementiert. 
 	 */
	private class ListClickHandler extends MouseAdapter {
		
		public void mouseClicked(MouseEvent e) {
			
			// Doppelklick mit linker Taste auf Liste, wird ein Dialog eineer Ware geoeffnet.
			if (e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) { 
				
				// Ein vorhandene Ware wird bearbeitet
				int index = getSelectedIndex();
				
				//oeffnen das Dialog der selektierten Ware
				if (index >= 0)	{
					
					DialogshowData diashow = new DialogshowData(mainframe, "show" , mainframe );
				
					
					
				}
			}
					
		}
		
	}

	/**
	 * GUIMusiksliste verbindt mit MusiksFrame.
	 * Maushandler in guiListe reagieren.
	 */
	public GUIWarenlist (Hauptframe a ) { 
		
		this.mainframe = a ;
		
		// Model und Liste verbinden
		setModel (myListModel);
		
		// Maushandler verbinden, um auf Doppelklick zu reagieren
		addMouseListener (new ListClickHandler()); 
	}
	
	public DefaultListModel<String> getMyListModel() {
		
		return myListModel;
		
	}

	//Elemente in guiListe initialisieren
	public void setWaren (ArrayList<Ware> warenlist) { 
		
		// Initialisierung der Warenliste		
		myListModel.removeAllElements();               
		int nWare = warenlist.size() ;                 
		for (int i = 0 ; i < nWare ; ++i) {  
			
			myListModel.addElement(warenlist.get(i).getName());   
		}
		
	}
}
