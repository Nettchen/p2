package model;

import java.io.IOException;




public class WarenDAO  extends DAO {
	
	/**
	 * Konstruktor um das Data Access Object mit einem Dateinamen zu initialisieren.
	 * 
	 * @param dateiName Dateiname
	 * @param openForWrite true wenn geschrieben werden soll
	 */
	
	public WarenDAO (String dateiName, boolean openForWrite) {

		super (dateiName, openForWrite);
	}
	
	
	public void write (Object obj) throws IOException {
		
		if (out != null) {
			
			Waren waren = (Waren)obj; 
			
			out.writeInt(waren.size());   // Anzahl Waren speichern  
			
			WareDAO wDAO = new WareDAO (null, out);  // Nun die einzelnen Waren speichern
			
			for (Ware w: waren) {     
				
				wDAO.write(w);
			}
		}
	}
	
	
	public void read (Object obj) throws IOException {
		
		if (in != null) {
			
			Waren waren = (Waren)obj;
			
			
			int nWare = in.readInt();    // Anzahl Waren lesen           
			
			
			WareDAO wDAO = new WareDAO (in, null);  // Nun die einzelnen Waren lesen:
			for (int i=0; i<nWare; ++i) {           
				Ware w = new Ware();                
				wDAO.read(w);                       
				waren.add(w);                       
			}
		}
	}
	
}
