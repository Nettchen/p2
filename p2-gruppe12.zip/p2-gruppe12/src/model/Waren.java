package model;

import java.util.ArrayList;


public class Waren extends ArrayList<Ware> { 
	
	
	public void addWare ( Ware w ) { 
		
		super.add(w) ;
		
	}

}
