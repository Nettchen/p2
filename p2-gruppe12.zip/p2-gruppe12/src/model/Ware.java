package model;

public class Ware {
	
	private String Name ;
	private int Nummer ;
	private boolean Lager ;
	private double Preis ;
	
	public Ware ( String name ,int num , boolean lager ,double preis ) {
		this.Nummer = num ;
		this.Name = name ;
		this.Preis = preis ;
		this.Lager  = lager ;		
	}

	public Ware() {
		// TODO Auto-generated constructor stub
	}

	public int getNummer() {
		return Nummer;
	}

	public void setNummer(int nummer) {
		Nummer = nummer;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public double getPreis() {
		return Preis;
	}

	public void setPreis(double preis) {
		Preis = preis;
	}

	public boolean isLager() {
		return Lager;
	}

	public void setLage(boolean lager) {
		Lager = lager;
	}
	
	
}
