package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;

import Model.Musik;
import Model.Musiks;

/**
 * GUIMusikListe erben von JList.
 */

public class GUIMusiksliste extends JList<String> {

	private MusiksFrame frame;
	
	
	
	/* Hier definieren wir einen Eventhandler, um auf Mausereignisse zu reagieren.
	 * Funktion: "�nderung" wird hier implementiert. 
 	 */
	private class ListClickHandler extends MouseAdapter {
		
		public void mouseClicked(MouseEvent e) {
			
			// Doppelklick mit linker Taste auf Liste, wird ein Dialog eines Musiktitels ge�ffnet.
			if (e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) {
				
				// Ein vorhandener Musik wird bearbeitet
				int index = getSelectedIndex();
				
				if (index >= 0)	{
					
					//�ffnen das Dialog des selektierten Musiktitel
					Musik m = frame.music.get(index);
					MusikDialog dlg = new MusikDialog (frame, m);
					
					if (dlg.closedOK) {
					// GUI-Elemente mit Daten aktualisieren	
						frame.updateGUI();
						
					}
				}
			}
		}
}


	/**
	 * GUIMusiksliste verbindt mit MusiksFrame.
	 * Maushandler in guiListe reagieren.
	 * Ein Bild wird in guiListe als Hintergrund benutzt.
	 */

	public GUIMusiksliste (MusiksFrame frame) {
		
		this.frame = frame;
		
		// Model und Liste verbinden�
		setModel (Constant.myListModel);
		
		// Maushandler verbinden, um auf Doppelklick zu reagieren�
		addMouseListener (new ListClickHandler());
		
		//BorderLayout wird benutzt und ein Bild hinzuf�gen in guiListe 
		setLayout(new BorderLayout());
		add(new JLabel(new ImageIcon("Images\\bild1.JPG")),BorderLayout.EAST);
		
		
	}
	/**
	 * Elemente in guiListe initialisieren .
	 */
	public void setMusiks (Musiks music) {
		// Initialisierung der Musiksliste
		Constant.myListModel.removeAllElements();
		
		for (Musik m: music) {
			Constant.myListModel.addElement(m.getTitel());
		}
		
	}
}








