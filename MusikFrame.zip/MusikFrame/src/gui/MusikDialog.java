package gui;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Model.Musik;
import gui.MusiksFrame.NorthPanel.FirstLine;
import gui.MusiksFrame.NorthPanel.SecondLine;

/**
 * Dialogfenster für neue Musiktitel hinzufügen und ändern.
 * Kilcken auf Button "Ok" kann man den neuen Musiktitel hinzufügen.
 */

public class MusikDialog extends JDialog implements ActionListener{
    
	//Wenn auf den Button "Ok" geklickt wird, wird Dialog beendet.(closeOK = true)
	public boolean closedOK = false;	
	
	// Referenz auf dem Musik-Objekt als Datenquelle
	private Musik myMusik;
	
	// Hinzufügen Dialogelemente (als Instanzvariablen)
	
	private JTextField 		titel     = new JTextField(10);	// 10 Spalten
	private JLabel			lblTitel   = new JLabel("Titel");
	private JTextField 		interpret     = new JTextField(10);//10 Spalten
	private JLabel			lblInterpret  = new JLabel("Interpret");
	
	//Aufzählung mehrerer Musikstile
	private String wahl;
	private String[] texte ={"Bitte auswaehlen Sie","Genres","PoP","Hip Hop","R&B/Soul Music","Rock","Country Music","Hard Rock Music",
			"Alternative Rock ","Electronica Music","Punk","Jazz","Blues"};
	
	//ComboBox hinzufügen 
	private JComboBox<String>		stil     = new JComboBox<String>(texte);
	private JLabel			lblStil  = new JLabel("Stil");
	
	//Spieldauer 
	private JTextField 		spieldauer    = new JTextField(10);// 10 Spalten
	private JLabel			lblSpieldauer  = new JLabel("Spieldauer");
	
	//Mit CheckBox prüfen Musiktitel, ob partygeeignet ist. 
	private JLabel			lblPartygeeignet  = new JLabel("Partygeeignet");
	private JCheckBox		partygeeignet = new JCheckBox(" ");
	
	//Quelle
	private JTextField 		quelle      = new JTextField(20);// 20 Spalten
	private JLabel			lblQuelle   = new JLabel("Quelle");
	
	//Button "Ok" und "Abbrechen"
	private JButton			ok		  = new JButton("OK");
	private JButton			abbrechen = new JButton("Abbrechen");
	
	
	/**
	 * Konstruktor initialisiert den Dialog.
	 * Wenn ein neue Musiktitel angelegt wird, ist das ergebenen Musikobjekt leer. 
	 * Wird ein vorhandener Musiktitel bearbeitet, werden dessen Daten zu Initialisierung
	 * der GUI-Elemente verwendet.
	 */
	
	public MusikDialog (Window parent, Musik m) {
		
		super (parent, "Neue Musik", Dialog.ModalityType.APPLICATION_MODAL ); // Modaler Dialog, Titel wird später gesetzt
	 myMusik = m;
		
		// Entnehmen  die Daten aus Musiktobjekt 
		titel.setText(m.getTitel());
		interpret.setText(""+m.getInterpret());  
		partygeeignet.setSelected(m.getPartygeeignet());
		quelle.setText(""+m.getQuelle());
		stil.setSelectedItem(""+m.getStil());
		
		// double-Wert für Spieldauer in formatierten String mit 2 Dezimalstellen:
		DecimalFormatSymbols dfs = DecimalFormatSymbols.getInstance();
		dfs.setDecimalSeparator(',');	// Dezimalkomma statt Punkt
		DecimalFormat df = new DecimalFormat ("0.00", dfs);  // 2 Dezimalstellen
		spieldauer.setText(df.format(m.getSpieldauer()));
		
		
		
		
		// Layout festlegen und GUI-Elemente hinzufugen
		class WestPanel extends Box {
			/**
			 * Layout in FirstLine entwerfen.
			 */
			class FirstLine extends JPanel {
				public FirstLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblTitel);
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (titel);
				}
			}
			class SecondLine extends JPanel {
				/**
				 * Layout in SecondLine entwerfen.
				 */
				public SecondLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblInterpret);
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (interpret);
				}
			}
			class ThirdLine extends JPanel {
				/**
				 * Layout in ThirdLine entwerfen.
				 */
				public ThirdLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblStil);
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (stil);
				}
			}
			class FouthLine extends JPanel {
				/**
				 * Layout in FouthLine entwerfen.
				 */
				public FouthLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblPartygeeignet);
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (partygeeignet);
				}
			}
			class FifthLine extends JPanel {
				/**
				 * Layout in FifthLine entwerfen.
				 */
				public FifthLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblSpieldauer);
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (spieldauer);
				}
			}
			class SixthLine extends JPanel {
				/**
				 * Layout in SixthLine entwerfen.
				 */
				public SixthLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblQuelle);
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (quelle);
				}
			}
			/**
			 * BoxLayout in WestPanel entwerfen.
			 */
			public WestPanel () {
				
				// 6 Zeilen sukzessiv aufkommen
				super (BoxLayout.Y_AXIS);
				add (new FirstLine());
				add (new SecondLine());
				add (new ThirdLine());
				add (new FouthLine());
				add (new FifthLine());
				add (new SixthLine());
				
			}
		}
		
		// Am SouthPanel gibt es zwei Button "OK" und "Abbrechen" und FlowLayout genutzt wird.
		class SouthPanel extends JPanel {
			/**
			 * Layout in SouthPanel entwerfen.
			 */
			public SouthPanel() {
				setLayout (new FlowLayout(FlowLayout.RIGHT));
				add (ok);
				add (abbrechen);
			}
		}
		 
	

	
		setLayout (new BorderLayout());
		add (new WestPanel(), BorderLayout.WEST);
		add (new SouthPanel(), BorderLayout.SOUTH);
		
		
		
		// Event-Handler installieren
		ok.addActionListener (this);
		abbrechen.addActionListener (this);
		
			
		//Einstellung des Dialogfensters
		    this.setIconImage((new ImageIcon("Images\\logo.gif")).getImage());
			this.setTitle ("Neue Musik");
			this.setLocation(300,50);   //Koordination: x=300, y=50;
			this.setSize (400, 500);	// Breite: 400 Pixel; Hoehe: 500 Pixel
			this.setVisible (true);	    // Fensterrahmen sichtbar machen
		
	
	}

	/**
	 *  Klicken auf Button "Ok" (neue Musiktitel hinzufügen) oder "Abbrechen" auswerten
	 */
   
	public void actionPerformed (ActionEvent e) {
				
		// Schältfläche entnehmen  
		Object source = e.getSource();
		
		if (source == ok) {
			// Werte des Musik-Objekts entsprechend den Dialogelementen aktualisieren
			myMusik.setTitel (titel.getText());
			myMusik.setInterpret (interpret.getText());
		    
			//SpieldauerZeit hat Dezimalkomma.
		    double spieldauerZeit = 0.00;      // Voreinstellung(Spielauer =0.0), falls Textumwandlung schief geht
		  
		    //To format a number for a different locale. specify it in the call to getInstance.
		    //Formalieren Sie eine Nummer für eine andere Locale,geben Sie es in dem Aufruf von getInstance.
		    NumberFormat nf = NumberFormat.getInstance();
			
			try {
				Number num = nf.parse(spieldauer.getText());
				spieldauerZeit = num.doubleValue();
			}
			catch (ParseException ex) {
			}
			myMusik.setSpieldauer(spieldauerZeit);
			myMusik.setPartygeeignet(partygeeignet.isSelected());
			myMusik.setQuelle (quelle.getText());
            myMusik.setStil((String) stil.getSelectedItem());
           
		    //true,wenn Dialog durch Ok beendet wird.
			closedOK = true;
		}
		// Dialog schliessn
		setVisible (false);
	}


	
}
