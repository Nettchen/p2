package gui;

import javax.swing.DefaultListModel;

public class Constant {
	//Eine DefaultListModel wird benutzt, um die guiListe "myListModel" zu kontrolieren.
	public static DefaultListModel<String> myListModel = new DefaultListModel<String> ();
}
