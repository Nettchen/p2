package gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ListModel;
import javax.swing.plaf.ListUI;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.xml.soap.Text;

import Model.Musik;
import Model.Musiks;
import Model.MusiksDAO;





/**
 * Hauptfenster mit einigen Button-Funktionen.
 * Klicken auf die Datei-Menü, kann man die Projekt mit "data" öffnen und speichern.(Funktion: speichern und öffnen)
 * Klicken auf den Button "Hinzufügen",wird ein Dialog gegeben. Mann kann hier einen neuen Musiktitel hinzufügen.(Funktion: Hinzufügen eines neues Musiktitels)
 * Doppelklicken auf einen Musiktitel, der in der Liste stellt, kann man diesen Musiktitel ändern.
 * (Funktion: Ändern eines vorhandenen Musiktitels)
 * Auswählen einen Musiktitel,der in der Liste stellt. Danach klicken auf den Button"Löschen", kann man diesen Musiktitel löschen.
 * (Funktion: Entfernen eines vorhandenen Musiktitels)
 * Schreiben den ganzen Musiktitel und klicken auf den Button "Suchen", kann man diesen Musicktitel suchen. Der gesuchte Musiktitel
 * wird markiert.(Funktion: Suchen eines Titels) 
 */


public class MusiksFrame extends JFrame implements ActionListener {




	

	Musiks music = new Musiks();  // package Sichtbarkeit, damit GUIMusiksliste zugreifen kann
	
	// GUI-Elemente als Instanzvariablen
	private GUIMusiksliste guiListe = new GUIMusiksliste(this);

	private JTextField 		txtAnzahlSpieldauer   = new JTextField(10);	// 10 Spalten
	private JLabel			lblAnzahlSpieldauer   = new JLabel("alle Musiktitel                      "); 
	
	private JTextField 		txtAnzahlPartygeeignet = new JTextField(10);	// 10 Spalten
	private JLabel			lblAnzahlPartygeeignet	 = new JLabel("alle partygeeigneten Titel");

	private JTextField 		Durchschnitt   = new JTextField(10);// 10 Spalten
	private JLabel			DurchschnittlichSpieldauer  = new JLabel("     Durchschnittliche Spieldauer aller Musiktitel:");
	
	private JTextField 		PartygeeignetZeit   = new JTextField(10);// 10 Spalten
	private JLabel			Partygeeignet  = new JLabel("Gesamte Spieldauer aller partygeeigneten Titel:");
	
	private JButton			btnNeuMusik		 = new JButton("Hinzufügen");
	
	private JButton			btnAendernMusik		 = new JButton("Ändern");
	
	private JButton			btnLoeschenMusik		 = new JButton("Löschen");
	
	private JTextField 		txtTitelEingeben   = new JTextField(15);// 15 Spalten
	private JLabel			lblTitelEingeben	 = new JLabel("Bitte einen ganzen Titel eingeben");
	private JButton         btnSuchenMusik		 = new JButton("Suchen");
	
	
     /**
	 * Aufbauen einen Dateimenü für das Hauptfenster.
	 */
	public class MenuLeiste extends JMenuBar {
		
		/**
		 * Konstruktor initialisiert die Menuleiste.
		 */
		public MenuLeiste () {
			
			add (new DateiMenu());
		}
		
		
		/**
		 * Hinzufügen ein Menü "Datei".
		 */
		class DateiMenu extends JMenu {
			
			/**
			 * Konstruktor initialisiert das Menü.
			 */
			public DateiMenu () {
				//Konstruktur der SuperKlasse wird angerufen.
				super ("Datei");
				add (new DateiOeffnenItem());//Hinzufügrn eine neue DateiOeffenItem;
				addSeparator();
				add (new DateiSpeichernItem());//Hinzufügrn eine neue DateiSpeichernItem;
			}
			
			
			/**
			 * Hinzufügen einen Menuintrag für "Datei offnen".
			 */
			class DateiOeffnenItem extends JMenuItem implements ActionListener {
				
				/**
				 * Konstruktor initialisiert den Menuintrag.
				 */
				public DateiOeffnenItem () {
					super ("Oeffnen");			// Verbinden Öffnen-MenuItem mit MeunItem.  
					addActionListener (this);	// Reagieren auf Klicken.
				}

				/**
				 * Reagieren auf Klick MenuItem "Öffnen" .
				 */
				public void actionPerformed(ActionEvent e) {
				
					
					//Auswählen eine Datei in Dialog
					JFileChooser fc = new JFileChooser();
					int returnValue = fc.showOpenDialog(MusiksFrame.this);
					if (returnValue == JFileChooser.APPROVE_OPTION) {
						
						File file = fc.getSelectedFile();
						String fileName = file.toString();
						MusiksDAO dao = new MusiksDAO (fileName, false);
						try {
							dao.read( music);
							dao.close();
						} 
						catch (IOException ex) {
						}
						updateGUI();
					}
				}
			}

			/**
			 * Hinzufügen einen Menuintrag fur "Datei Speichern" .
			 */
			class DateiSpeichernItem extends JMenuItem implements ActionListener {
				
				/**
				 * Konstruktor initialisiert den Menuintrag.
				 */
				public DateiSpeichernItem () {
					super ("Speichern");
					addActionListener (this);
				}
				
				/**
				 * Reagieren auf Klick MenuItem "Speichern" .
				 */
				public void actionPerformed(ActionEvent e) {
					
					//Auswählen eine Datei in Dialog.
					JFileChooser fc = new JFileChooser();
					int returnValue = fc.showOpenDialog(MusiksFrame.this);
					if (returnValue == JFileChooser.APPROVE_OPTION) {
						File file = fc.getSelectedFile();
						String fileName = file.toString();
						MusiksDAO dao = new MusiksDAO (fileName, true);
						try {
							dao.write(music);
							dao.close();
						} 
						catch (IOException ex) {
						}
					}
				}
			}

			
		}

	}

	/**
	 * Layout entwerfen(BorderLayout und FlowLayout)
	 */
	class NorthPanel extends Box {
		
		class FirstLine extends JPanel {
			/**
			 * Layout in FirstLine entwerfen.
			 */
			public FirstLine() {
				//Links werden Label "alle Musiktitel" und TextField "die Anzahl der Musiktitel" gezeigt.
				setLayout (new FlowLayout(FlowLayout.LEFT));
				add (lblAnzahlSpieldauer);
				add (txtAnzahlSpieldauer);
				//Rechts werden Label "Durchschnittlich Spieldauer alle Musiktitel" und TextField "die Resultat" gezeigt.
				setLayout (new FlowLayout(FlowLayout.RIGHT));
				add (DurchschnittlichSpieldauer);
				add (Durchschnitt);
			}
		}
		
		class SecondLine extends JPanel {
			/**
			 * Layout in SecondLine entwerfen.
			 */
			public SecondLine() {
				//Links werden Label "alle partygeeigneten Titel" und TextField "die Anzahl aller partygeeigeneten Musiktitel" gezeigt.
				setLayout (new FlowLayout(FlowLayout.LEFT));
				add (lblAnzahlPartygeeignet);
				add (txtAnzahlPartygeeignet);
				
				//Rechts werden Label "Gsamte Spieldauer aller partygeeigneten Musiktitel" und TextField "die Resultat" gezeigt.
				setLayout (new FlowLayout(FlowLayout.RIGHT));
				add (Partygeeignet);
				add (PartygeeignetZeit);
			}
		}
		/**
		 * BoxLayout in NorthPanel entwerfen.
		 */
		public NorthPanel () {
			
			//Hinzufügen 2 Zeilen auf BoxLayout. 
			super (BoxLayout.Y_AXIS);
			add (new FirstLine());
			add (new SecondLine());
		   
		}
	}

	
class SouthPanel extends Box {
		
		class FirstLine extends JPanel {
			/**
			 * Layout in FirstLine entwerfen.
			 */
			public FirstLine() {
				//Links werden Label "Bitte einen ganzen Titel eingeben" und TextField "der Name des Musiktitels" gezeigt.
				setLayout (new FlowLayout(FlowLayout.LEFT));
				add (lblTitelEingeben);
				add (txtTitelEingeben);
				//Hinzufügen einen Button"Suchen".
				add (btnSuchenMusik);	
			
			}
		}
		class SecondLine extends JPanel {
			/**
			 * Layout in SecondLine entwerfen.
			 */
			public SecondLine() {
                //Layout von Button "Hinzüfügen" und "Löschen" entwerfen
				setLayout (new FlowLayout(FlowLayout.RIGHT));
      			add (btnNeuMusik);
      			add (btnAendernMusik);
			    add (btnLoeschenMusik);
			}
		}
		
		/**
		 * BoxLayout in SouthLine entwerfen.
		 */
		public SouthPanel () {
			
			// 2 Zeilen untereinander
			super (BoxLayout.Y_AXIS);
			add (new FirstLine());
			add (new SecondLine());
			
		}
	}
	
	
	/**
	 * Konstruktor initialisiert Anwendungsfenster.
	 */
	public MusiksFrame () {
		
		// Das Hauptfenster soll auf den Beenden-Klicken 'Fenster schliessen reagieren'.
		setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

		//Die Instanz für die obere MenuLeiste und komponente zum Container hinzufügen
		setJMenuBar (new MenuLeiste());

		// Musiksdatenliste in GUI-Liste ertragen:
		guiListe.setMusiks(music);
		
		// Layout setzen und GUI-Elemente hinzufügen
		setLayout (new BorderLayout());
		add (new NorthPanel(), BorderLayout.NORTH);
		add (guiListe        , BorderLayout.CENTER);
		add (new SouthPanel(), BorderLayout.SOUTH);
		
		// Event-Handler installieren:
		btnSuchenMusik.addActionListener (this);
		btnNeuMusik.addActionListener (this);
		btnLoeschenMusik.addActionListener(this);
		btnAendernMusik.addActionListener(this);

      
   
		
		
		// Eigenschaften des Fensters festlegen
		    this.setIconImage((new ImageIcon("Images\\logo.gif")).getImage());//Logo hinzufügen
			this.setTitle ("Welcome to JadeCloudMusik!");
			this.setLocation(300,50); //Hauptfensterkoordination bestimmen
			this.setSize (800, 600); // Breite: 800 Pixel; Hoehe: 600 Pixel
			this.setVisible (true);	// Fensterrahmen sichtbar machen
	}
	
	/**
	 * Klicken auf Button "Hinzufügen" auswerten
	 */
	
	public void actionPerformed (ActionEvent arg0) {
		
//Reagieren  auf klick des Buttons "Hinzufügen".
   if (arg0.getSource()==btnNeuMusik){
	   // Neues Musik-Objekt erzeugen:
		Musik m = new Musik();
		// Dialog zum Bearbeite des neuen Objekts zeigen:
		MusikDialog dlg = new MusikDialog(this, m);
		
		if (dlg.closedOK) {
			// Neuen Musiks hinzufuen:
			music.addMusik(m);
			
			// Neue GUI-Elemente mit Daten aktualisieren
			updateGUI();
		}
		
		}
   
   //Reagieren  auf klick des Buttons "Ändern".
   else if (arg0.getSource()==btnAendernMusik){
	   JOptionPane.showMessageDialog(this, "Doppelkilckt auf einen Musiktitel um einen Fenster, in dem der Musiktitel geändert werden kann, zu öffnen");
		}
		
		
    
   //Reagieren  auf klick des Buttons "Löschen".
		else if (arg0.getSource()==btnLoeschenMusik){
			
			int index = guiListe.getSelectedIndex();
			//nicht erfolgreich einen Musiktitel auswählen
			if (index == -1)	{
				JOptionPane.showMessageDialog(this, "Bitte eine Zeile auswaelen");
				return;
			}
			//erfolgreich einen Musiktitel auswählen
			else if (index !=-1){
				//myListModel ruft die Methode in Klass "Constant" an 
				//myListmodel und guiListe verbinden
				//Einen Musiktitel in guiListe ausgewählt wird 
				Constant.myListModel.remove(guiListe.getSelectedIndex());
				
				//löschen gewählte Zeile
				music.remove(index);
				
				// GUI-Elemente mit Daten aktualisieren
				updateGUI();
				}
		}
   
                //Reagieren  auf klick des Buttons "Suchen".
	
		else if (arg0.getSource()==btnSuchenMusik){
			
			ListModel<String> model = guiListe.getModel();
           
			
		    //erhalten die eingegebene Titel
			//public String trim(), benuztet man diese Methode, wenn schreibt man Leerzeichen am Anfang und am Ende  keine Behinderung für Erhaltung des Titels 			     
			String suchtext = txtTitelEingeben.getText().trim();
             
			  //erhalten Anzahl der Musiktitel
              int size = model.getSize();
              
              //Die ganze Musiktitel prüfen einzeln.
              for (int i = 0; i < size; i++) {
                 Object o = model.getElementAt(i);
              //Hier kann man prüfen, ob es passende Musiktitel in guiListe gibt   
                 if (o.equals(suchtext)) {
                 guiListe.setSelectedIndex(i);
                 return;
                  }
              }
              //Wenn keine passende Musiktitel gesucht wird, zeigt ein Dialog "Ooops!!! Not found".
                  guiListe.setSelectedIndex(-1);   
                  JOptionPane.showMessageDialog(this, "Ooops!!! Not found. "); 
                 return;   
           }
		}
	

  
 
	 
	void updateGUI () {
		
		// Musiksdatenliste in GUI-Liste ertragen:
		guiListe.setMusiks(music);
		
		// Auswertung für AnzahlSpieldauer aktualisieren
		txtAnzahlSpieldauer.setText(""+music.size());
		
		// Auswertung für Anzahl der partygeeigneten Musiktitel aktualisieren
		txtAnzahlPartygeeignet.setText(""+music.anzahlPartygeeignet());	
		
		//Auswertung für druchschbittliche Spieldauer aktualisieren
		Durchschnitt.setText(""+music.DurchschnittlicheZeit());
		
		// Auswertung für die gesamte Zeit der partygeeigneten Musiktitel aktualisieren
		PartygeeignetZeit.setText(""+music.PartygeeignetZeit());
	}
	

		

	/**
	 * Hier startet unsere Anwendung.
	 */
	public static void main (String[] args) {
		
		/**
		 * Hier merken wir uns die Referenz des Anwendungsfenster in einer Klassenvariablen.
		 */
				new MusiksFrame();
			
			
		}
	}



