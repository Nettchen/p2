package Model;

public class Musik {

	//Alle Elemente von Musiktitel initialisieren.
	private String titel;
	private String interpret;
	private String stil;
	private double spieldauer;
	private boolean partygeeignet;
	private String quelle;
	
	
	public Musik() {
	}
	/**
	 * Hier werden alle Elemente des Musiktitels definiert.
	 */
	public Musik (String titel, String interpret, String stil, double spieldauer, boolean partygeeignet, String quelle) {
		
		this.titel = titel;
		this.interpret = interpret;
		this.stil = stil;
		this.spieldauer = spieldauer;
		this.partygeeignet = partygeeignet;
		this.quelle = quelle;
	}
	
	
	public String getTitel() {
		return titel;
	}
	public void setTitel(String titel) {
		this.titel = titel;
	}
	public String getInterpret() {
		return  interpret;
	}
	public void setInterpret(String  interpret) {
		this. interpret =  interpret;
	}
	public String getStil() {
		return stil;
	}
    public void setStil(String stil){
	this.stil=stil;
    }
	public double getSpieldauer() {
		return spieldauer;
	}
	public void setSpieldauer(double spieldauer) {
		this.spieldauer = spieldauer;
	}
	public boolean getPartygeeignet() {
		return partygeeignet;
	}
	public void setPartygeeignet(boolean partygeeignet) {
		this.partygeeignet = partygeeignet;
	}
	public String getQuelle() {
		return quelle;
	}
	public void setQuelle(String quelle) {
		this.quelle = quelle;
	}

}
	

	
	

