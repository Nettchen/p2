package Model;

import java.util.ArrayList;



/**
 * Diese Klasse stellt eine Liste von Musiks dar.
 */
public class Musiks extends ArrayList<Musik> {

	
	/**
	 * F�gt einen neuen Musiks zur Liste hinzu.
	 * @param s Referenz auf Musik-Objekt.
	 */
	public void addMusik (Musik m) {
		
		super.add(m);
	}
	/**
	 * Rechnen der Anzahl von "Partygeeignet"
	 */
	
	public int anzahlPartygeeignet  () {
		
		int nPartygeeignet  = 0;
		for (Musik m: this) {
			
			if (m.getPartygeeignet ()) 
				nPartygeeignet++;
		}
		return nPartygeeignet ;
	}	
	/**
	 * Rechnen der Durchschnitt von "SpieldauerZeit aller Musiktitel"
	 */	

	public double DurchschnittlicheZeit(){
		//Anzahl der Durchf�hrung von "For-schleife".
		//Index==guiListe.size
	    int Index=0;
		double Durchschnitt=0;
		for (Musik m: this) {
			Durchschnitt=Durchschnitt+m.getSpieldauer();
		    Index++;
		}
		
         return Durchschnitt/Index;
	}
		
	/**
	 *Rechnen der Gesamtzeit von "alle Partygeeignet"
	 */
	 public double PartygeeignetZeit(){
       double Gesamtzeit=0;
		 for (Musik m:this){
    	   if (m.getPartygeeignet())
              Gesamtzeit=Gesamtzeit+m.getSpieldauer();         
       }
		 return Gesamtzeit;
}
}
