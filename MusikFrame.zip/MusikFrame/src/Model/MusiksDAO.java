package Model;

import java.io.IOException;



/**
 * Data Access Object f�r die Klasse Musiks.
 */
public class MusiksDAO  extends DAO {
	
	
	/**
	 * Konstruktor um das Data Access Object mit einem Dateinamen zu initialisieren.
	 * 
	 * @param dateiName Dateiname
	 * @param openForWrite true wenn geschrieben werden soll
	 */
	public MusiksDAO (String dateiName, boolean openForWrite) {

		super (dateiName, openForWrite);
	}
	
	
	public void write (Object obj) throws IOException {
		
		if (out != null) {
			
			Musiks music = (Musiks)obj;
			// Anzahl Musiks speichern:
			out.writeInt(music.size());
			
			// Nun die einzelnen Musiks speichern:
			MusikDAO musikDAO = new MusikDAO (null, out);
			
			for (Musik m: music) {
				
				musikDAO.write(m);
			}
		}
	}
	
	/**
	 * Neues Musik-Objekt erzeugen und Daten aus Datei lesen.
	 */	
	public void read (Object obj) throws IOException {
		
		if (in != null) {
			
			Musiks music = (Musiks)obj;
			
			// Anzahl der Musiks lesen:
			int nMusic = in.readInt();
			
			// Nun die einzelnen Musiks lesen:
			MusikDAO musicDAO = new MusikDAO (in, null);
		
			for (int i=0; i<nMusic; ++i) {
				Musik m = new Musik();
				musicDAO.read(m);
				music.add(m);
			}
		}
	}
	
}
