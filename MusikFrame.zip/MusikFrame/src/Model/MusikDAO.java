package Model;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;




/**
 * Data Access Object f�r die Klasse Musik.
 */
public class MusikDAO extends DAO {

	
	/**
	 * Konstruktor um das Data Access Object mit einem Dateinamen zu initialisieren.
	 * 
	 * @param dateiName Dateiname
	 * @param openForWrite true wenn geschrieben werden soll
	 */
	public MusikDAO (String dateiName, boolean openForWrite) {
		
		super (dateiName, openForWrite);
	}
	
	
	/**
	 * Konstruktor um das Data Access Object mit bereits vorhandenen Streams zu initialisieren.
	 * 
	 * @param in InputStream oder null
	 * @param out OutputStream oder null
	 */
	public MusikDAO (DataInputStream in, DataOutputStream out) {
		
		super (in, out);
	}
	
	
	/**
	 * Daten des �bergebenen Musik-Objekts schreiben. Das Data Access Object muss dazu zum
	 * Schreiben bereit sein.
	 * 
	 * @param s Referenz auf Musik-Objekt
	 * @throws IOException
	 */
	public void write (Object obj) throws IOException {
		
		if (out != null) {
			
			Musik m = (Musik)obj;
			
			out.writeUTF	(m.getTitel());
			out.writeUTF	(m.getInterpret());
			out.writeUTF	(m.getStil());
			out.writeUTF	(m.getQuelle());
			out.writeBoolean(m.getPartygeeignet());
			out.writeDouble	(m.getSpieldauer());
		}
	}
	
	
	/**
	 * Daten des �bergebenen Musik-Objekts lesen. Das Data Access Objekt muss dazu zum
	 * Lesen bereit sein.
	 * 
	 * @param s Referenz auf Musik-Objekt
	 * @throws IOException
	 */
	public void read (Object obj) throws IOException {
		
		if (in != null) {
			
Musik m = (Musik)obj;
			
			m.setTitel   	(in.readUTF());
			m.setInterpret	(in.readUTF());
			m.setStil	    (in.readUTF());
			m.setQuelle 	(in.readUTF());
			m.setPartygeeignet	(in.readBoolean());
			m.setSpieldauer		(in.readDouble());
		}
	}
}
